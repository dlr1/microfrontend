import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Mfe1HomeComponent } from './mfe1-home/mfe1-home.component';
import { Mfe1RoutingModule } from './mfe1-routing.module';


@NgModule({
  declarations: [
   Mfe1HomeComponent
  ],
  imports: [
    BrowserModule,    
    Mfe1RoutingModule
  ]
})
export class Mfe1Module { }
