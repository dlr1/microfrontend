import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mfe1-home',
  templateUrl: './mfe1-home.component.html',
  styleUrls: ['./mfe1-home.component.scss']
})
export class Mfe1HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
