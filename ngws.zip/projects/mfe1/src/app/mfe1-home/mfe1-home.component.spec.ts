import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Mfe1HomeComponent } from './mfe1-home.component';

describe('Mfe1HomeComponent', () => {
  let component: Mfe1HomeComponent;
  let fixture: ComponentFixture<Mfe1HomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Mfe1HomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Mfe1HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
