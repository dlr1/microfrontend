import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Mfe1HomeComponent } from './mfe1-home/mfe1-home.component';

const routes: Routes = [
  { path: 'mfe1-home', component: Mfe1HomeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Mfe1RoutingModule { }
